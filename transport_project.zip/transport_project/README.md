# FleetWise - Assistant Stratégique de Gestion des Tâches de Transport

FleetWise est une application web complète conçue pour automatiser et optimiser le processus de calcul des coûts de transport, la planification d'itinéraires et l'assignation des tâches aux chauffeurs. L'objectif est de remplacer les estimations manuelles par des décisions précises, basées sur des données, afin d'augmenter la rentabilité et l'efficacité opérationnelle.

## 🛠 Architecture Technique

- **Backend :** Django 5.2.5 + Django REST Framework
- **Frontend :** React 19.1.1 (Single Page Application)
- **Base de Données :** MySQL 8.0+
- **API Externe :** OpenRouteService pour les calculs géographiques
- **Notifications :** Système d'email via SMTP Django

## 📋 Prérequis

### Système
- **Python 3.9+** 
- **Node.js 16+** et npm
- **MySQL 8.0+**
- Connexion internet (pour l'API OpenRouteService)

### Comptes et Clés API
- Base de données MySQL configurée
- Compte email SMTP (Gmail recommandé)
- Clé API OpenRouteService (déjà incluse dans le projet)

## 🚀 Installation et Configuration

### 1. Cloner le Projet

```bash
git clone <url-du-repo>
cd transport_project
```

### 2. Configuration Backend (Django)

#### a) Créer l'environnement virtuel
```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

#### b) Installer les dépendances
```bash
pip install -r requirements.txt
```

#### c) Configuration de la base de données
1. Créez une base de données MySQL nommée `fleetwise_db`
2. Modifiez les paramètres dans `FleetWise/settings.py` si nécessaire :

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'fleetwise_db',  
        'USER': 'votre_utilisateur_mysql',         
        'PASSWORD': 'votre_mot_de_passe_mysql',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

#### d) Configuration Email (Optionnel)
Modifiez les paramètres email dans `FleetWise/settings.py` :

```python
EMAIL_HOST_USER = 'votre_email@gmail.com'
EMAIL_HOST_PASSWORD = 'votre_mot_de_passe_application'
```

#### e) Migrations et superutilisateur
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
```

### 3. Configuration Frontend (React)

```bash
cd ../frontend
npm install
```

### 4. Démarrage des Serveurs

#### Terminal 1 - Backend Django
```bash
cd backend
# Activer l'environnement virtuel si pas encore fait
python manage.py runserver
```
Le serveur Django sera accessible sur `http://localhost:8000`

#### Terminal 2 - Frontend React
```bash
cd frontend
npm start
```
L'application React sera accessible sur `http://localhost:3000`

## 📊 Structure des Données

### Modèles de Base de Données

#### 1. **Camion**
- `nom` : Nom du camion (ex: "Volvo FH-16")
- `consommation` : Consommation en L/100km

#### 2. **Chauffeur**
- `nom` : Nom complet du chauffeur
- `email` : Adresse email pour l'envoi des missions

#### 3. **TrajetPeage**
- `ville_depart` : Ville de départ
- `ville_arrivee` : Ville d'arrivée
- `prix` : Prix du péage en MAD

#### 4. **ParametresGeneraux** (Singleton)
- `prix_carburant` : Prix du carburant par litre
- `tarif_horaire_chauffeur` : Coût horaire du chauffeur
- `marge_benefice_par_defaut` : Marge de bénéfice (0.20 = 20%)

## 🎯 Guide d'Utilisation

### 1. Configuration Initiale (Admin)

1. Accédez à l'onglet **Administration**
2. Configurez les **Paramètres Généraux** :
   - Prix carburant : ex. 14.50 MAD/L
   - Tarif horaire : ex. 50.00 MAD/h
   - Marge bénéfice : ex. 0.20 (20%)

3. Ajoutez vos **Camions** avec leurs consommations réelles
4. Ajoutez vos **Chauffeurs** avec leurs emails
5. Configurez les **Péages** pour les principales autoroutes

### 2. Calcul d'Itinéraires (Tableau de Bord)

1. Saisissez la **ville de départ** et **ville d'arrivée**
2. Sélectionnez un **camion** dans la liste
3. Cliquez **"Calculer les Itinéraires"**
4. Analysez les différentes options proposées
5. Sélectionnez l'itinéraire optimal

### 3. Assignation de Mission

1. Cliquez **"Assigner cette Mission"** sur l'itinéraire choisi
2. Sélectionnez un **chauffeur**
3. Ajoutez des **notes spéciales** si nécessaire
4. Confirmez l'envoi
5. Le chauffeur recevra automatiquement l'email avec les détails

## 🔧 API REST - Endpoints

### Endpoints Principaux

- `POST /api/calculer-itineraire/` - Calcul d'itinéraires
- `POST /api/envoyer-mission/` - Envoi de mission par email
- `GET/PUT /api/parametres/` - Gestion des paramètres

### Endpoints CRUD

- `/api/camions/` - Gestion des camions
- `/api/chauffeurs/` - Gestion des chauffeurs  
- `/api/peages/` - Gestion des péages

### Endpoints Utilitaires

- `/api/status/` - Statut de l'API
- `/api/health/` - Santé du système

## 🌍 API OpenRouteService

Le système utilise l'API OpenRouteService pour :
- **Géocodage** : Conversion des noms de villes en coordonnées
- **Calcul d'itinéraires** : Routes optimisées pour poids lourds
- **Détection des autoroutes** : Pour l'application des tarifs de péage

La clé API est déjà configurée dans le projet.

## 📧 Système d'Email

### Fonctionnalités
- Envoi automatique des missions aux chauffeurs
- Contenu exclusivement opérationnel (pas d'infos financières)
- Templates HTML et texte
- Liens de navigation Google Maps

### Configuration Gmail
1. Activez l'authentification à 2 facteurs
2. Générez un "Mot de passe d'application"
3. Utilisez ce mot de passe dans les settings Django

## 🎨 Interface Utilisateur

### Caractéristiques
- **Langue :** Exclusivement en français
- **Design :** Interface moderne et responsive
- **Navigation :** Tableau de bord + Administration
- **Accessibilité :** Compatible mobile et tablette

### Pages Principales
- **Tableau de Bord :** Calcul et assignation des missions
- **Administration :** Gestion des données et paramètres

## 🐛 Dépannage

### Problèmes Courants

#### "API non accessible"
- Vérifiez que le serveur Django est démarré
- Contrôlez l'URL dans `frontend/src/services/api.js`

#### "Erreur de base de données"
- Vérifiez les paramètres MySQL dans `settings.py`
- Assurez-vous que la base existe et est accessible

#### "Aucun itinéraire trouvé"
- Vérifiez la connexion internet
- Utilisez des noms de villes principales du Maroc
- Vérifiez les logs du serveur Django

#### "Email non envoyé"
- Configurez les paramètres SMTP
- Vérifiez les paramètres de sécurité Gmail
- Contrôlez les logs d'erreur Django

### Logs et Debug

#### Backend (Django)
```bash
cd backend
python manage.py runserver --verbosity=2
```

#### Frontend (React)
Ouvrez les outils développeur du navigateur (F12)

## 📁 Structure du Projet

```
transport_project/
├── backend/
│   ├── FleetWise/          # Configuration Django
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── ...
│   ├── fleetWiseApp/       # Application principale
│   │   ├── models.py       # Modèles de données
│   │   ├── views.py        # Vues API
│   │   ├── services.py     # Logique métier
│   │   ├── serializers.py  # Sérializers DRF
│   │   └── ...
│   ├── requirements.txt    # Dépendances Python
│   └── manage.py
├── frontend/
│   ├── src/
│   │   ├── components/     # Composants React
│   │   │   ├── dashboard/  # Composants tableau de bord
│   │   │   └── admin/      # Composants administration
│   │   ├── pages/          # Pages principales
│   │   ├── services/       # Services API
│   │   ├── App.js          # Composant principal
│   │   └── App.css         # Styles
│   ├── package.json        # Dépendances Node.js
│   └── ...
└── README.md
```

## 🚀 Production

### Déploiement

1. **Base de données :** Utilisez un serveur MySQL dédié
2. **Backend :** Configurez avec uWSGI/Gunicorn + Nginx
3. **Frontend :** Build et servez les fichiers statiques
4. **Sécurité :** Activez HTTPS et mettez à jour `settings.py`

### Optimisations

- Activez le cache Django
- Configurez la compression des assets
- Utilisez un CDN pour les fichiers statiques
- Monitorer les performances API

## 📞 Support

Pour toute question technique ou problème d'utilisation :

1. Consultez d'abord la section dépannage
2. Vérifiez les logs d'erreur
3. Consultez la documentation des APIs utilisées
4. Contactez l'équipe de développement

## 📄 Licence

Ce projet est développé pour un usage interne d'entreprise de transport.

---

**FleetWise v1.0** - Solution de Gestion de Transport Intelligente  
© 2025 - Développé avec Django & React
